package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"json:target/reports/cucumberReport.json", "html:target/reports/"}, ///Vamos colocar as configurações do report de testes
        features = "src/test/resources/features",  ///A pasta aonde os bdd vão ficar
        tags = {"@comprar-ingresso"}, ///Aonde vão ficar as tags de testes
        glue = {"steps"}  /// Aonde estão os steps
)
public class RunCucumberTest {
    // Aqui estamos configurando oque ira acontecer antes e no final de cada teste
    public static WebDriver driver;

    @BeforeClass
    public static void start() {
        System.out.println("Iniciou!");
            driver = new ChromeDriver();   //Aqui iniciamos o teste
    }

    @AfterClass
    public static void stop() {
        System.out.println("Finalizou!");
            driver.quit();   //Aqui finalizamos e fechamos o navegador
    }
}

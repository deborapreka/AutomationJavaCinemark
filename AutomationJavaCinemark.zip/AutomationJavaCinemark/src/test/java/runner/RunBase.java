package runner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RunBase {

    static WebDriver driver;

    private enum Browser {CHROME}
    public static WebDriver getDriver(){
        if(driver == null){
            getDriver(Browser.CHROME);
        } else {
            return driver;
        }
        return  null;
    }
    public static WebDriver getDriver(Browser browser){
        if(driver != null){
            driver.quit();
        }
        switch (browser){
            case CHROME:
                driver = new ChromeDriver();
                break;
            default:
                throw new IllegalArgumentException("Passe um navegador valido");
        }
        return  null;
    }
}

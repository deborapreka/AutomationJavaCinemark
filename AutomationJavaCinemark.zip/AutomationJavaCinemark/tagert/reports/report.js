$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("simulacaodecompra.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "# language: pt"
    }
  ],
  "line": 3,
  "name": "Comprar um ingresso no site do cinemark",
  "description": "Eu como usuário do cinemark\r\nquero escolher um filme\r\npara comprar os ingressos",
  "id": "comprar-um-ingresso-no-site-do-cinemark",
  "keyword": "Funcionalidade"
});
formatter.scenario({
  "line": 8,
  "name": "Comprar os ingressos no site do cinemark",
  "description": "",
  "id": "comprar-um-ingresso-no-site-do-cinemark;comprar-os-ingressos-no-site-do-cinemark",
  "type": "scenario",
  "keyword": "Cenário"
});
formatter.step({
  "line": 9,
  "name": "que estou no site do cinemark",
  "keyword": "Dado "
});
formatter.step({
  "line": 10,
  "name": "clico em progamação",
  "keyword": "Quando "
});
formatter.step({
  "line": 11,
  "name": "clico na opção em cartaz",
  "keyword": "E "
});
formatter.step({
  "line": 12,
  "name": "clico em sinopse e horario",
  "keyword": "E "
});
formatter.step({
  "line": 13,
  "name": "clico em compre aqui",
  "keyword": "E "
});
formatter.step({
  "line": 14,
  "name": "escolho uma sessão",
  "keyword": "E "
});
formatter.step({
  "line": 15,
  "name": "escolho um assento",
  "keyword": "E "
});
formatter.step({
  "line": 16,
  "name": "clico em prosseguir",
  "keyword": "E "
});
formatter.step({
  "line": 17,
  "name": "seleciono o tipo de ingresso inteira",
  "keyword": "E "
});
formatter.step({
  "line": 18,
  "name": "clico em prosseguir",
  "keyword": "E "
});
formatter.step({
  "line": 19,
  "name": "insiro o email",
  "keyword": "E "
});
formatter.step({
  "line": 20,
  "name": "insiro a senha",
  "keyword": "E "
});
formatter.step({
  "line": 21,
  "name": "clico em entrar",
  "keyword": "E "
});
formatter.step({
  "line": 22,
  "name": "clico em Nao obrigado no popup",
  "keyword": "E "
});
formatter.step({
  "line": 23,
  "name": "clico em pagamento",
  "keyword": "E "
});
formatter.step({
  "line": 24,
  "name": "preencho o campo numero do cartão",
  "keyword": "E "
});
formatter.step({
  "line": 25,
  "name": "preencho o campo nome impresso",
  "keyword": "E "
});
formatter.step({
  "line": 26,
  "name": "preencho o campo CPF do titular",
  "keyword": "E "
});
formatter.step({
  "line": 27,
  "name": "preencho o campo mes e ano",
  "keyword": "E "
});
formatter.step({
  "line": 28,
  "name": "preencho o CVV",
  "keyword": "E "
});
formatter.step({
  "line": 29,
  "name": "visualizo o botão de finalizar pedido",
  "keyword": "Então "
});
formatter.match({
  "location": "CompraStep.acessar_site_cinemark()"
});
formatter.result({
  "duration": 4834610900,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.botao_progamacao()"
});
formatter.result({
  "duration": 241992200,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.opcao_emcartaz()"
});
formatter.result({
  "duration": 2388994300,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.opcao_sinopse()"
});
formatter.result({
  "duration": 2489361500,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.botao_compreaqui()"
});
formatter.result({
  "duration": 15814917000,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.escolher_sessao()"
});
formatter.result({
  "duration": 7666667900,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.escolho_assento()"
});
formatter.result({
  "duration": 134879400,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.clico_prosseguir()"
});
formatter.result({
  "duration": 5205517200,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.seleciono_ingresso()"
});
formatter.result({
  "duration": 133332900,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.clico_prosseguir()"
});
formatter.result({
  "duration": 1690861000,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.insiro_email()"
});
formatter.result({
  "duration": 257027800,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.insiro_senha()"
});
formatter.result({
  "duration": 148413600,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.clico_entrar()"
});
formatter.result({
  "duration": 5601292200,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.rejeitar_popup_de_snack()"
});
formatter.result({
  "duration": 1456904400,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.botao_pagamento()"
});
formatter.result({
  "duration": 8134041500,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.numero_cartao()"
});
formatter.result({
  "duration": 140697300,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.campo_nome()"
});
formatter.result({
  "duration": 129094300,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.CPF_Titular()"
});
formatter.result({
  "duration": 131836200,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.data_expiracao()"
});
formatter.result({
  "duration": 129595900,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.cvv()"
});
formatter.result({
  "duration": 116859000,
  "status": "passed"
});
formatter.match({
  "location": "CompraStep.finalizar_pedido()"
});
formatter.result({
  "duration": 172538900,
  "status": "passed"
});
});